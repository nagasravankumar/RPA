package com.cg.solution;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

/**
 * This program reads the length of the cloth, stores it in an array
 * The cloth is cut for every iteration with the lowest number from the array
 * till the cloth size is >=1. The above operation is repeated till each
 * element of the array don�t have >1 length cloth. Then print the times each 
 * cloth is cut on Nth iteration.
 * @author mmendke
 *
 */


/**********************************
 * 		TestCase 1 Input :
 * 		5		  : No.of items
 * 12 23 34 45 56 : Length of cloth
 * ********************************/

/*****************************************
 *   		TestCase 1 Output :
 * For 0th iteration the length of cloth is:
 *	12 23 34 45 56 
 *	Till 1th iteration the clothes are cut for:
 *	[1, 1, 1, 1, 1]
 *	after cutting length of cloth is:
 *	0 11 22 33 44 

 *	Till 2th iteration the clothes are cut for:
 *	[1, 2, 2, 2, 2]
 *	after cutting length of cloth is:
 *	0 0 11 22 33 

 *	Till 3th iteration the clothes are cut for:
 *	[1, 2, 3, 3, 3]
 *	after cutting length of cloth is:
 *	0 0 0 11 22 

 *	Till 4th iteration the clothes are cut for:
 *	[1, 2, 3, 4, 4]
 *	after cutting length of cloth is:
 *	0 0 0 0 11 

 *	Till 5th iteration the clothes are cut for:
 *	[1, 2, 3, 4, 5]
 *	after cutting length of cloth is:
 *	0 0 0 0 0 

 *	After final iteration the clothes are cut for:
 *	1th cloth is cut for:1
 *	2th cloth is cut for:2
 *	3th cloth is cut for:3
 *	4th cloth is cut for:4
 *	5th cloth is cut for:5
 ****************************************/

public class Solution3New {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number of items:");
		int n = sc.nextInt();		// n, no. of cloth element
		int[] arr =  new int[n];	
		int[] count = new int[n];	// Count the times each cloth is cut for every iteration
		int flag = 0;				// To check till all the elements become zero
		int j=0;
		
		System.out.println("Enter the length of "+n+" cloth");
		for(int i=0;i<n;i++)
		{
			arr[i] = sc.nextInt();
			if(arr[i]<0)
			{
				System.out.println("Length must be positive");
				i--;
			}
		}
		
		System.out.println("For 0th iteration the length of cloth is:");
		for(int i=0;i<n;i++)
		{	
			System.out.print(arr[i]+" ");
		}
		System.out.println("");
		int temp = 0 ;
		while(flag<n)
		{

			flag = 0;
			for(int i=0;i<n;i++)
			{	
				if(arr[i]!=0)
					temp = arr[i];
			}

			/* Obtaining the smallest length of the cloth */

			for(int i=0;i<n;i++)
			{
				if(temp > arr[i] && arr[i] > 0)	// If true temp is assigned smallest length
					temp = arr[i];
			}
			for(int i=0;i<n;i++)
			{
				
				if(arr[i]!=0)
				{
					arr[i] = arr[i]-temp;				// Subtracting the smallest length from others
					count[i]++;							// Incrementing the count after the iteration
				}if(arr[i]==0)
				{
					flag++;
				}
			}
			j++;

			System.out.println("Till "+j+"th iteration the clothes are cut for:");
			System.out.println(Arrays.toString(count));	// printing the number of cuts till that iteration

			System.out.println("after cutting length of cloth is:" );  
			for(int i=0;i<n;i++)
				System.out.print(arr[i]+" ");
			System.out.println("");
			System.out.println("");

		}
		System.out.println("");
		System.out.println("After final iteration the clothes are cut for:");	// printing the number of cuts after final iteration
		for(int i=1;i<=n;i++)
			System.out.println(i+"th cloth is cut for:"+count[i-1]);

	}
	}
	
