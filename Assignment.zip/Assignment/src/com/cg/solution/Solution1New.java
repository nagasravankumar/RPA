package com.cg.solution;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * This program implements an application that
 * validates the email Id and display valid and invalid 
 * to the standard output accordingly 
 * @author mmendke
 *
 */


/***********************************
 * 					TestCases:
 * 		Input			:	Output
 *  mpmen@gmail.com		:	Valid
 *	mpm_123@gmail.com	:	Valid
 *	Mpm@gma.com			:	Invalid
 *	mpm_34@gmail.com	:	Valid
 *	mpm_67@				:	Invalid
 *	mpm_345@.			:	Invalid
 *	mpm.com				:	Invalid
 *
 ************************************/
public class Solution1New {

	public static void main(String[] args) {

		Scanner sc = new Scanner (System.in);
		
		/* we make use of regular expression 
		 * in order to validate input email Id 
		 */

		String pat = "([a-z]{1,6})([_]{0,1}[0-9]{0,4})@[\\w]+\\.[A-Za-z]{2,}";
		String a="y";
		while(a.equalsIgnoreCase("Y"))
		{
		System.out.println("Enter the email Id:");
		//User enters the email Id
		String emailid = sc.nextLine();
		/* Using pattern and matcher */
		Pattern pattern = Pattern.compile(pat);
		Matcher matcher = pattern.matcher(emailid);

		if(matcher.matches())			//If true then valid is printed at output
			System.out.println("Valid");

		else							//If false then invalid is printed at output
			System.out.println("Invalid");
		System.out.println("Do you wish to continue?");
		System.out.println("Press y for yes and n for no");
		String b = sc.nextLine();
		a = b;
		}
	}

}

