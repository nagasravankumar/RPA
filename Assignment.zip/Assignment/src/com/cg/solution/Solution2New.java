package com.cg.solution;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Solution2New {

	public static void main(String[] args) throws FileNotFoundException {
		FileReader fr = new FileReader("src/test.txt");
		Scanner fileScanner = new Scanner(fr);
		/* Hashset used to store all the unique words */
		Set<String> slist = new HashSet<String>();

		/* ArrayList used to store the lines of the file */
		List<String> alist = new ArrayList<String>();

		while (fileScanner.hasNextLine()) {				// Checking for new line
		  String line = fileScanner.nextLine();
		  if(line.length()==0)
			  System.out.println("\"Empty\"");
		  else
		  System.out.println(line);
		  Scanner lineScanner = new Scanner(line);
		  while (lineScanner.hasNext()) {				// Iterating through line for the current line
		    String token = lineScanner.next();
		    for(String arr : token.split("[\\n\\s\\.]+"))  // splitting string for blank spaces and full stops
				{
		    		arr = arr.toUpperCase();
					slist.add(arr);
					alist.add(arr);
				}
		  }
		  
		  for(String s : slist)
			{int count=0;			// counter to count the occurrences of the word
			for(String a : alist)
			{
				if(a.equalsIgnoreCase(s))
				{	
					count++;
				}
			}
			if(count > 1)
			{
				System.out.println(s+"\t"+count);
			}
			}
		  slist.clear();
		  alist.clear();
		  lineScanner.close();
		  
		}
		fileScanner.close();

	}

}
