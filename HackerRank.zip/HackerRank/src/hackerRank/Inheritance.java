package hackerRank;

public class Inheritance {
	static String str="";
	 public static class TextInput {
		 void add(char c) {
			 String str1 = Character.toString(c);
				str = str.concat(str1);
		 }
		 String getValue()
		 {
			 return str;
		 }
	 }

	    public static class NumericInput extends TextInput{
	    	void add(char c) {
				if(c>='0'&&c<='9')
				{
	    		String str1 = Character.toString(c);
				str = str.concat(str1);
				}
			 }
			
		 }
	    

	    public static void main(String[] args) {
	        TextInput input = new NumericInput();
	        input.add('1');
	        input.add('a');
	        input.add('0');
	        System.out.println(input.getValue());
	    }

}
