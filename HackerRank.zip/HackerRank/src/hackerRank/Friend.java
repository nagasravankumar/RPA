package hackerRank;

import java.util.Collection;
import java.util.Iterator;
import java.util.Stack;
import java.util.ArrayList;

public class Friend {
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Friend other = (Friend) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		return true;
	}
	private Collection<Friend> friends;
	private String email;

	public Friend(String email) {
		this.email = email;
		this.friends = new ArrayList<Friend>();
	}

	public String getEmail() {
		return email;
	}

	public Collection<Friend> getFriends() {
		return friends;
	}

	public void addFriendship(Friend friend) {
		friends.add(friend);
		friend.getFriends().add(this);
	}

	public boolean canBeConnected(Friend friend) {
		// public boolean canBeFriends(Friend friend) {
			System.out.println(email + " is connecting with " + friend.email);

			Stack<Friend> stack = new Stack<Friend>();
			Stack<Friend> friendsVisited = new Stack<Friend>(); // To keep track
			// which Friend
			// objects have been
			// already visited
			stack.addAll(friend.getFriends());
			friendsVisited.addAll(friend.getFriends());

			if (friends.contains(friend)) {
				return true;
			} else {
				while (!stack.isEmpty()) {
					Friend tmpFriend = stack.pop();
					if (this.getEmail().equals(tmpFriend.getEmail())) {
						return true;
					} else {
						for (Friend frnd : tmpFriend.getFriends()) {
							if (!stack.contains(frnd)
									&& !friendsVisited.contains(frnd)) {
								stack.push(frnd);
								friendsVisited.push(frnd);
							}
						}

					}
				}
			}

			return false;
	}

	public static void main(String[] args) {
		Friend a = new Friend("A");
		Friend b = new Friend("B");
		Friend c = new Friend("C");
		Friend d = new Friend("D");
		Friend e = new Friend("E");
		Friend f = new Friend("F");
		Friend g = new Friend("G");
		Friend h = new Friend("H");


		b.addFriendship(c);
		c.addFriendship(f);// C-->D
		d.addFriendship(e);
		e.addFriendship(f);
		a.addFriendship(d);
		a.addFriendship(b);
		System.out.println(a.canBeConnected(c));
		System.out.println(a.canBeConnected(f));
		System.out.println(a.canBeConnected(d));
		System.out.println(a.canBeConnected(h));


	}
}