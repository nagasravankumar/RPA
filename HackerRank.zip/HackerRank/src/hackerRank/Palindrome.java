package hackerRank;

public class Palindrome {
    public static boolean isPalindrome(String word) {
       // throw new UnsupportedOperationException("Waiting to be implemented.");
    	int len = word.length();
    	int count=0;
    	word = word.toLowerCase();
    	String str = new String(word);
    	for(int i=0;i<len;i++)
    	{
    		if(str.charAt(len-1-i)==(word.charAt(i)))
    		{
    			count++;
    		}
    	}
    	if(count==len)
    		return true;
    	else
    		return false;
    }
    
    public static void main(String[] args) {
        System.out.println(Palindrome.isPalindrome("DDeeleveled"));
    }
}