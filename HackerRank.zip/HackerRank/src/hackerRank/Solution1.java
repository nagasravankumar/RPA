package hackerRank;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Solution1 {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		Set<String>list = new HashSet<String>();
		int t = s.nextInt();
		String [] pair_left = new String[t];
		String [] pair_right = new String[t];
		String [] pair = new String[t];
		for (int i = 0; i < t; i++) {
			pair_left[i] = s.next();
			pair_right[i] = s.next();
			pair[i] = pair_left[i]+","+pair_right[i];
		}
		int len=list.size();
		int count = len;
		//System.out.println(Arrays.toString(pair));
		for (int i = 0; i < t; i++) {
			list.add(pair[i]);
			count++;
			if(list.size() == count)
			{
				System.out.println(count);
			}
			else
				{
				count--;
				System.out.println(count);
				}
		}
	}
}
