package hackerRank;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Scanner;

import org.jsoup.Jsoup;

public final class TextURL{
	public static void main(String[] args) throws IOException {
		Scanner scan = new Scanner(System.in);
		URL u = new URL("https://en.wikipedia.org/wiki/Pune");
		
		BufferedReader br = new BufferedReader(new InputStreamReader(u.openStream()));
		
		int count = 0;
		System.out.println("Enter the word you want to count:");
		String str = scan.nextLine().toLowerCase();
		
		String text;
		while(( text = br.readLine())!=null) {	
			org.jsoup.nodes.Document doc = Jsoup.parse(text); 
			String inp =  doc.body().text();
			inp = inp.replaceAll("[\\(]?", "");	 
			String[] words =inp.split("[\\s\\.\\,\\?\\:\\;\\-\\n\\']"); 
			 for(String a:words) {
				 if(str.equals(a.toLowerCase())) {
					count++;
				}
				 }
			}
		if(count>0) {
			System.out.println("Word '"+str+ "' is repeated :"+count+ " times.");
		}else {
			System.out.println("Word not repeated.");
		}
		
		br.close();
	}

}
