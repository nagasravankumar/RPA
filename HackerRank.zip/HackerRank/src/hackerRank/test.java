package hackerRank;

import java.util.*;
public class test {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Deque<Integer[]> deque = new ArrayDeque<Integer[]>();
        int n = in.nextInt();
        int m = in.nextInt();
        int[] num = new int[n];
        for (int i = 0; i < n; i++) {
            num[i] = in.nextInt();
        }
        
        for(int i=0;i<m-1;)
        {
        	Integer[] sub = new Integer[m];
        	for(int j=0;j<m;j++)
        		{
        		sub[j]= num[i];
        		i++;
        		}
        	deque.add(sub);
        	
        }
        System.out.println(Arrays.toString(deque.toArray()));
    }
}