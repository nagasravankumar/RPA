package hackerRank;

import java.util.Arrays;
import java.util.Scanner;

public class Solution{
	public static void main(String[] args){

		Scanner in = new Scanner(System.in);
		//int testCases = Integer.parseInt(in.nextLine());
		/*while(testCases>0){*/
			String line = in.nextLine();
			String[] arr = line.split(">(\"[^\"]*\"|'[^']*'|[^'\">])*<");
			System.out.println(Arrays.toString(arr));
			if((arr.length%2)!=0)
				System.out.println("None");
			else
			{
			for(String x: arr)
			{
				for(int i=0;i<x.length();i++)
				{
					
				}
			}
			}
			
			/*testCases--;
		}*/
	}
}