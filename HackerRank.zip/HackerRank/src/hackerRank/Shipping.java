package hackerRank;
public class Shipping {
    public static int minimalNumberOfPackages(int items, int availableLargePackages, int availableSmallPackages) {
        //throw new UnsupportedOperationException("Waiting to be implemented.");
        int[] large = new int[5];
       int count=0;
       if(items<=0)
           return 0;
        for(int j=0;j<availableLargePackages;j++)
        {
        for(int i=0;i<5;i++)
        {
        	if(items>0)
        	{
        		large[i] = 1;
        		items--;
        	}
        }
        count++;
        if(items<=0)
        {
        	return count;
        }	
        }
        /*if(items>0)
        {*/
        for(int j=0;j<availableSmallPackages;j++)
        {
        	if(items>0)
            {
        	count++;
        	items--;
            }
        	if(items<=0)
        	{
        		return count;
        	}
        }
        //}
       // if(items>0)
        return -1;
    }
    
    public static void main(String[] args) {
        System.out.println(minimalNumberOfPackages(5, 1, 2));
    }
}