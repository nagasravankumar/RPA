package hackerRank;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
class ArrayListProgram{
   public static void main(String []argh)
   {
		Scanner in = new Scanner(System.in);
		HashMap<String, Integer> hm = new HashMap<String, Integer>();
		ArrayList<String> query = new ArrayList<String>();
		int count=0;
		String id =null;
		int ph = 0;
		int n=in.nextInt();
		in.nextLine();
		for(int i=0;i<n;i++)
		{
			String name=in.nextLine();
			int phone=in.nextInt();
			hm.put(name, phone);
			in.nextLine();

		}
		int i=0;
		while(i<3)
		{

			String s=in.nextLine();
			query.add(s);
			i++;
		}
		//System.out.println(query);
		/* Set<String> keys = hm.keySet();
		for(int i1=0;i1<query.size();i1++)
		{String str = query.get(i1);
			for(String k : keys)
			{
				if(hm.containsKey(str))
				{
					System.out.println(k+"="+hm.get(k));
					break;

				}
				else
				{
					System.out.println("Not found");
					break;
				}
			}
		}
		 */
		Set<Entry<String, Integer>> entires = hm.entrySet();
		for(String str : query)
		{
			for(Entry<String, Integer> ent:entires)
			{
				if(ent.getKey().equals(str))
				{ System.out.println(ent.getKey()+"="+ent.getValue());
					count=0;
				break;
				}
				else
					count=1;
			}
			if(count==1)
			{
				System.out.println("Not found");
			}
			count=0;
		}
	}
}
