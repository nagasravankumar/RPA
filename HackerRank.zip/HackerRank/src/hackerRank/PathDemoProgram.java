package hackerRank;

import java.util.Arrays;

public class PathDemoProgram {
	private String path;

	public PathDemoProgram(String path) {
		this.path = path;
	}

	public String getPath() {
		return path;
	}

	public void cd(String newPath) {
		int count=0;
		String[] str = newPath.split("\\/");
		String[] str1 = path.split("\\/");
		for(String x : str)
		{
			if(x.equals(".."))
			{
				count++;
			}
		}
		
		int j=0;
		int a=0;
		
		if(count>0)
		{
			for(int i=0;i<count;i++)
			{
				for(;j<str.length;j++)
				{
					if(str[j].matches("[A-Z]*[a-z]*"))
					{
						str1[str1.length-1-i] = str[j]; 
						a=1;
						break;
					}
				}

			}
			
			if(a==0)
			{
				String[] str3 = new String[str1.length-count-1];
				for(int i=0;i<str1.length-count-1;i++)
				{
					str3[i] = str1[i+1];
				}
				
				path="";
				for(String x : str3)
				{
					path = path.concat("/"+x);
				}
			}
			else
			{
				String[] str2 = new String[str1.length-count];
				for(int i=0;i<str1.length-count;i++)
				{
					str2[i]=str1[i+1];
				}

				path="";
				for(String x : str2)
				{

					path = path.concat("/"+x);
				}
			}
		}
		if (count==0)
		{
			
			System.out.println(Arrays.toString(str));
			for(int i=1;i<str.length;i++)
			{
				path = path.concat("/"+str[i]);
			}
		}

	}

	public static void main(String[] args) {
		PathDemoProgram path = new PathDemoProgram("/a/b/c/d");
		path.cd("/x");
		System.out.println(path.getPath());
	}
}