package hackerRank;

public class TwoSum {
	public static int[] findTwoSum(int[] list, int sum) {
		int len = list.length;
		int [] arr = new int[2];
		int i=0;
		
		for(;i<len-1;i++)
		{
			for(int j=i+1;j<len;j++)
			{
				int sum1 = list[i]+list[j];
				if(sum==sum1)
				{
					arr[0]=i;
					arr[1]=j;
					return arr;
				}
			}
		}
		return null;
	}


	public static void main(String[] args) {
		int[] indices = findTwoSum(new int[] { 1, 3, 5, 7, 9 }, 12);
		System.out.println(indices[0] + " " + indices[1]);
	}
}