package hackerRank;

import java.util.Collection;
import java.util.HashSet;

public class XMLFolders {
	public static Collection<String> folderNames(String xml, char startingLetter) throws Exception {
		//throw new UnsupportedOperationException("Waiting to be implemented.");
		Collection<String> list = new HashSet<String>();
		String str1 = null;
		int i=0;
		int x=0;
		int end=0;
		for(;i<xml.length();i++)
		{
			int start = xml.indexOf("name=",end);
			end = start + 6;
			char c = xml.charAt(end);
			if(c == startingLetter)
			{
				x = xml.indexOf("\"", end);
				str1 = xml.substring(end, x);
				list.add(str1);
				
			}
			
		}
		return list;
	}

	public static void main(String[] args) throws Exception {
		String xml =
				"<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
						"<folder name=\"c\">" +
						"<folder name=\"program files\">" +
						"<folder name=\"uninstall information\" />" +
						"</folder>" +
						"<folder name=\"users\" />" +
						"</folder>";
		//System.out.println(xml.toString());
		Collection<String> names = folderNames(xml, 'u');
		for(String name: names)
			System.out.println(name);
	}
}
