package hackerRank;

import java.util.LinkedList;
public class TrainComposition {
   	static LinkedList<Integer> list = new LinkedList<Integer>(); 
    public void attachWagonFromLeft(int wagonId) {
    	list.add(0, wagonId);
        //throw new UnsupportedOperationException("Waiting to be implemented.");
    }

    public void attachWagonFromRight(int wagonId) {
    	list.add(wagonId);
        //throw new UnsupportedOperationException("Waiting to be implemented.");
    }

    public int detachWagonFromLeft() {
    	int i= list.get(0);
        list.remove(0);
        return i;
        //throw new UnsupportedOperationException("Waiting to be implemented.");
    }

    public int detachWagonFromRight() {
    	int i= list.get(list.size()-1);
        list.remove(list.size()-1);
        return i;
       // throw new UnsupportedOperationException("Waiting to be implemented.");
    }

    public static void main(String[] args) {
        TrainComposition tree = new TrainComposition();
        tree.attachWagonFromLeft(7);
        tree.attachWagonFromLeft(13);
        System.out.println(tree.detachWagonFromRight()); // 7 
        System.out.println(tree.detachWagonFromLeft()); // 13
    }
}